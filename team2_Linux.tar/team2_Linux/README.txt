2조_미니리눅스
유저: root, os, rae

./MLINUX가 열리지않으면
gcc -o MLINUX main.h main.c instruction.c directory.c user.c stack.c time.c -lpthread
를 입력하여 실행파일을 만들어주세요
